export type TTodosFilter = 'all' | 'active' | 'completed';
