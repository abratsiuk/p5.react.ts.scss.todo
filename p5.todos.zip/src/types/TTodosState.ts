export type TTodosState =
  | 'empty'
  | 'allActive'
  | 'anyActive-anyCompleted'
  | 'allCompleted';
