import './Header.scss';

export const Header = () => {
  return <div className="Header">todos</div>;
};
