export interface ITodosKindsNumber {
  all: number;
  active: number;
  completed: number;
}
