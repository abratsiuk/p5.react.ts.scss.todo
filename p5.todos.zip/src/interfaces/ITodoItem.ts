export interface ITodoItem {
  id: number;
  isCompleted: boolean;
  text: string;
}
